# وثائق التطوير لتطبيق المحاسبة المتوافق مع الأنظمة السعودية

## نظرة عامة على التطبيق

تطبيق المحاسبة المتوافق مع الأنظمة السعودية هو تطبيق أندرويد متكامل مصمم للشركات والمؤسسات في المملكة العربية السعودية. يوفر التطبيق جميع الوظائف المحاسبية الأساسية مع الالتزام الكامل بمتطلبات هيئة الزكاة والضريبة والجمارك، بما في ذلك الفوترة الإلكترونية وحساب ضريبة القيمة المضافة والزكاة.

## بنية التطبيق

تم تطوير التطبيق باستخدام نمط MVVM (Model-View-ViewModel) مع الاعتماد على مكتبات Android Jetpack. يتكون التطبيق من الطبقات التالية:

### طبقة العرض (Presentation Layer)
- **الأنشطة (Activities)**: تمثل الشاشات الرئيسية للتطبيق.
- **الشظايا (Fragments)**: تمثل أجزاء واجهة المستخدم القابلة لإعادة الاستخدام.
- **المحولات (Adapters)**: تستخدم لعرض البيانات في قوائم وشبكات.
- **نماذج العرض (ViewModels)**: تربط بين واجهة المستخدم ومصادر البيانات.

### طبقة المنطق (Business Logic Layer)
- **الخدمات (Services)**: تنفذ منطق الأعمال المعقد مثل الفوترة الإلكترونية وحساب الضرائب والزكاة.
- **المستودعات (Repositories)**: توفر واجهة موحدة للوصول إلى البيانات.
- **الأدوات المساعدة (Utilities)**: توفر وظائف مساعدة مثل التشفير وإنشاء رموز الاستجابة السريعة.

### طبقة البيانات (Data Layer)
- **قاعدة البيانات (Database)**: تستخدم Room لتخزين البيانات محلياً.
- **كائنات الوصول للبيانات (DAOs)**: توفر واجهة للتفاعل مع قاعدة البيانات.
- **واجهات برمجة التطبيقات (APIs)**: تتفاعل مع خدمات هيئة الزكاة والضريبة والجمارك.

## التقنيات المستخدمة

- **لغة البرمجة**: Kotlin
- **إطار العمل**: Android Jetpack
- **قاعدة البيانات**: Room (SQLite)
- **التزامن**: Coroutines
- **حقن التبعية**: Dagger Hilt
- **الشبكة**: Retrofit, OkHttp
- **التشفير**: AES-256, SHA-256
- **رموز الاستجابة السريعة**: ZXing
- **اختبار**: JUnit, Mockito

## مخطط قاعدة البيانات

قاعدة البيانات تتكون من الجداول التالية:

1. **accounts**: يخزن معلومات الحسابات المحاسبية.
2. **customers**: يخزن معلومات العملاء.
3. **suppliers**: يخزن معلومات الموردين.
4. **products**: يخزن معلومات المنتجات.
5. **invoices**: يخزن معلومات الفواتير.
6. **invoice_items**: يخزن عناصر الفواتير.
7. **journal_entries**: يخزن القيود المحاسبية.
8. **journal_entry_items**: يخزن عناصر القيود المحاسبية.
9. **users**: يخزن معلومات المستخدمين.
10. **settings**: يخزن إعدادات التطبيق.

## المكونات الرئيسية

### نماذج البيانات (Models)

#### Account.kt
```kotlin
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Long,
    val code: String,
    val name: String,
    val type: AccountType,
    val parentId: Long?,
    val balance: Double,
    val isActive: Boolean,
    val createdAt: Date,
    val updatedAt: Date
)
```

#### Invoice.kt
```kotlin
data class Invoice(
    @PrimaryKey(autoGenerate = true) val id: Long,
    val invoiceNumber: String,
    val invoiceDate: Date,
    val dueDate: Date,
    val customerId: Long,
    val supplierId: Long,
    val invoiceType: InvoiceType,
    val status: InvoiceStatus,
    val subtotalAmount: Double,
    val discountAmount: Double,
    val taxAmount: Double,
    val totalAmount: Double,
    val paidAmount: Double,
    val remainingAmount: Double,
    val notes: String?,
    val isReported: Boolean,
    val reportedDate: Date?,
    val uuid: String,
    val createdAt: Date,
    val updatedAt: Date
)
```

### كائنات الوصول للبيانات (DAOs)

#### AccountDao.kt
```kotlin
@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts")
    fun getAllAccounts(): Flow<List<Account>>
    
    @Query("SELECT * FROM accounts WHERE type = :type")
    fun getAccountsByType(type: AccountType): Flow<List<Account>>
    
    @Insert
    suspend fun insertAccount(account: Account): Long
    
    @Update
    suspend fun updateAccount(account: Account)
    
    @Delete
    suspend fun deleteAccount(account: Account)
}
```

#### InvoiceDao.kt
```kotlin
@Dao
interface InvoiceDao {
    @Query("SELECT * FROM invoices")
    fun getAllInvoices(): Flow<List<Invoice>>
    
    @Query("SELECT * FROM invoices WHERE invoiceType = :type")
    fun getInvoicesByType(type: InvoiceType): Flow<List<Invoice>>
    
    @Insert
    suspend fun insertInvoice(invoice: Invoice): Long
    
    @Update
    suspend fun updateInvoice(invoice: Invoice)
    
    @Delete
    suspend fun deleteInvoice(invoice: Invoice)
}
```

### المستودعات (Repositories)

#### AccountRepository.kt
```kotlin
class AccountRepository @Inject constructor(
    private val accountDao: AccountDao
) {
    fun getAllAccounts() = accountDao.getAllAccounts()
    
    fun getAccountsByType(type: AccountType) = accountDao.getAccountsByType(type)
    
    suspend fun insertAccount(account: Account) = accountDao.insertAccount(account)
    
    suspend fun updateAccount(account: Account) = accountDao.updateAccount(account)
    
    suspend fun deleteAccount(account: Account) = accountDao.deleteAccount(account)
}
```

#### InvoiceRepository.kt
```kotlin
class InvoiceRepository @Inject constructor(
    private val invoiceDao: InvoiceDao,
    private val invoiceItemDao: InvoiceItemDao
) {
    fun getAllInvoices() = invoiceDao.getAllInvoices()
    
    fun getInvoicesByType(type: InvoiceType) = invoiceDao.getInvoicesByType(type)
    
    suspend fun insertInvoice(invoice: Invoice, items: List<InvoiceItem>) {
        val invoiceId = invoiceDao.insertInvoice(invoice)
        items.forEach { item ->
            invoiceItemDao.insertInvoiceItem(item.copy(invoiceId = invoiceId))
        }
    }
    
    suspend fun updateInvoice(invoice: Invoice) = invoiceDao.updateInvoice(invoice)
    
    suspend fun deleteInvoice(invoice: Invoice) = invoiceDao.deleteInvoice(invoice)
}
```

### الخدمات (Services)

#### EInvoiceService.kt
```kotlin
class EInvoiceService @Inject constructor(
    private val zatcaApiService: ZatcaApiService
) {
    fun generateInvoiceHash(invoice: Invoice): String {
        // تنفيذ منطق إنشاء تجزئة للفاتورة
    }
    
    fun encryptInvoiceData(invoice: Invoice, key: String): String {
        // تنفيذ منطق تشفير بيانات الفاتورة
    }
    
    fun generateInvoiceNumber(prefix: String, lastInvoiceNumber: Int, date: Date): String {
        // تنفيذ منطق إنشاء رقم فاتورة جديد
    }
    
    fun validateInvoice(invoice: Invoice, hash: String): Boolean {
        // تنفيذ منطق التحقق من صحة الفاتورة
    }
    
    suspend fun submitInvoiceToZatca(invoice: Invoice): Result<ZatcaInvoiceResponse> {
        // تنفيذ منطق إرسال الفاتورة إلى هيئة الزكاة والضريبة والجمارك
    }
}
```

#### TaxZakatService.kt
```kotlin
class TaxZakatService @Inject constructor() {
    fun calculateVAT(amount: Double, taxRate: Double): Double {
        // تنفيذ منطق حساب ضريبة القيمة المضافة
    }
    
    fun calculateAmountWithVAT(amount: Double, taxRate: Double): Double {
        // تنفيذ منطق حساب المبلغ شامل الضريبة
    }
    
    fun extractVATFromTotal(totalAmount: Double, taxRate: Double): Double {
        // تنفيذ منطق استخراج مبلغ الضريبة من المبلغ الإجمالي
    }
    
    fun isValidSaudiVATNumber(vatNumber: String): Boolean {
        // تنفيذ منطق التحقق من صحة الرقم الضريبي السعودي
    }
    
    fun calculateZakat(accounts: List<Account>, date: Date): Double {
        // تنفيذ منطق حساب الزكاة
    }
    
    fun generateVATReport(startDate: Date, endDate: Date, salesVAT: Double, purchasesVAT: Double): VATReport {
        // تنفيذ منطق إنشاء تقرير ضريبة القيمة المضافة
    }
}
```

### نماذج العرض (ViewModels)

#### AccountViewModel.kt
```kotlin
class AccountViewModel @Inject constructor(
    private val accountRepository: AccountRepository
) : ViewModel() {
    val accounts = accountRepository.getAllAccounts().asLiveData()
    
    fun getAccountsByType(type: AccountType) = accountRepository.getAccountsByType(type).asLiveData()
    
    fun insertAccount(account: Account) = viewModelScope.launch {
        accountRepository.insertAccount(account)
    }
    
    fun updateAccount(account: Account) = viewModelScope.launch {
        accountRepository.updateAccount(account)
    }
    
    fun deleteAccount(account: Account) = viewModelScope.launch {
        accountRepository.deleteAccount(account)
    }
}
```

#### InvoiceViewModel.kt
```kotlin
class InvoiceViewModel @Inject constructor(
    private val invoiceRepository: InvoiceRepository,
    private val eInvoiceService: EInvoiceService,
    private val taxZakatService: TaxZakatService
) : ViewModel() {
    val invoices = invoiceRepository.getAllInvoices().asLiveData()
    
    fun getInvoicesByType(type: InvoiceType) = invoiceRepository.getInvoicesByType(type).asLiveData()
    
    fun createInvoice(invoice: Invoice, items: List<InvoiceItem>) = viewModelScope.launch {
        invoiceRepository.insertInvoice(invoice, items)
    }
    
    fun updateInvoice(invoice: Invoice) = viewModelScope.launch {
        invoiceRepository.updateInvoice(invoice)
    }
    
    fun deleteInvoice(invoice: Invoice) = viewModelScope.launch {
        invoiceRepository.deleteInvoice(invoice)
    }
    
    fun submitInvoiceToZatca(invoice: Invoice) = viewModelScope.launch {
        val result = eInvoiceService.submitInvoiceToZatca(invoice)
        // معالجة النتيجة
    }
    
    fun calculateVAT(amount: Double, taxRate: Double): Double {
        return taxZakatService.calculateVAT(amount, taxRate)
    }
}
```

## الأدوات المساعدة (Utilities)

### EInvoiceUtil.kt
```kotlin
object EInvoiceUtil {
    fun generateUUID(): String {
        // تنفيذ منطق إنشاء معرف فريد
    }
    
    fun generateInvoiceHash(data: String): String {
        // تنفيذ منطق إنشاء تجزئة للفاتورة
    }
    
    fun encryptInvoiceData(data: String, key: String): String {
        // تنفيذ منطق تشفير بيانات الفاتورة
    }
    
    fun decryptInvoiceData(encryptedData: String, key: String): String {
        // تنفيذ منطق فك تشفير بيانات الفاتورة
    }
    
    fun generateQRCodeData(sellerName: String, vatNumber: String, invoiceTimestamp: String, invoiceTotal: Double, vatAmount: Double): String {
        // تنفيذ منطق إنشاء بيانات رمز الاستجابة السريعة
    }
}
```

### TaxZakatUtil.kt
```kotlin
object TaxZakatUtil {
    fun calculateVAT(amount: Double, taxRate: Double): Double {
        // تنفيذ منطق حساب ضريبة القيمة المضافة
    }
    
    fun calculateAmountWithVAT(amount: Double, taxRate: Double): Double {
        // تنفيذ منطق حساب المبلغ شامل الضريبة
    }
    
    fun extractVATFromTotal(totalAmount: Double, taxRate: Double): Double {
        // تنفيذ منطق استخراج مبلغ الضريبة من المبلغ الإجمالي
    }
    
    fun extractAmountBeforeVAT(totalAmount: Double, taxRate: Double): Double {
        // تنفيذ منطق استخراج المبلغ قبل الضريبة من المبلغ الإجمالي
    }
    
    fun formatInvoiceNumber(prefix: String, number: Int, date: Date): String {
        // تنفيذ منطق تنسيق رقم الفاتورة
    }
    
    fun isValidSaudiVATNumber(vatNumber: String): Boolean {
        // تنفيذ منطق التحقق من صحة الرقم الضريبي السعودي
    }
    
    fun calculateZakat(assets: Double, liabilities: Double, exemptedAssets: Double): Double {
        // تنفيذ منطق حساب الزكاة
    }
}
```

## واجهات برمجة التطبيقات (APIs)

### ZatcaApiService.kt
```kotlin
interface ZatcaApiService {
    @POST("invoices")
    suspend fun submitInvoice(
        @Header("Authorization") token: String,
        @Body request: ZatcaInvoiceRequest
    ): Response<ZatcaInvoiceResponse>
    
    @GET("taxpayers/{vatNumber}")
    suspend fun validateVatNumber(
        @Header("Authorization") token: String,
        @Path("vatNumber") vatNumber: String
    ): Response<ZatcaVatValidationResponse>
}
```

## اختبارات الوحدة

### TaxZakatUtilTest.kt
```kotlin
@RunWith(AndroidJUnit4::class)
class TaxZakatUtilTest {
    @Test
    fun testCalculateVAT() {
        // اختبار حساب ضريبة القيمة المضافة
    }
    
    @Test
    fun testCalculateAmountWithVAT() {
        // اختبار حساب المبلغ شامل الضريبة
    }
    
    @Test
    fun testExtractVATFromTotal() {
        // اختبار استخراج مبلغ الضريبة من المبلغ الإجمالي
    }
    
    @Test
    fun testIsValidSaudiVATNumber() {
        // اختبار التحقق من صحة الرقم الضريبي السعودي
    }
    
    @Test
    fun testCalculateZakat() {
        // اختبار حساب الزكاة
    }
}
```

### EInvoiceUtilTest.kt
```kotlin
@RunWith(AndroidJUnit4::class)
class EInvoiceUtilTest {
    @Test
    fun testGenerateUUID() {
        // اختبار إنشاء معرف فريد
    }
    
    @Test
    fun testGenerateInvoiceHash() {
        // اختبار إنشاء تجزئة للفاتورة
    }
    
    @Test
    fun testEncryptDecryptInvoiceData() {
        // اختبار تشفير وفك تشفير بيانات الفاتورة
    }
    
    @Test
    fun testGenerateQRCodeData() {
        // اختبار إنشاء بيانات رمز الاستجابة السريعة
    }
}
```

## اختبارات التكامل

### ZatcaComplianceTest.kt
```kotlin
@RunWith(AndroidJUnit4::class)
class ZatcaComplianceTest {
    @Mock
    private lateinit var zatcaApiService: ZatcaApiService
    
    private lateinit var eInvoiceService: EInvoiceService
    
    @Before
    fun setup() {
        MockitoAnnotations.openMocks(this)
        eInvoiceService = EInvoiceService()
    }
    
    @Test
    fun testSubmitInvoiceToZatca() {
        // اختبار إرسال فاتورة إلكترونية إلى هيئة الزكاة والضريبة والجمارك
    }
    
    @Test
    fun testValidateSaudiVATNumber() {
        // اختبار التحقق من صحة الرقم الضريبي السعودي
    }
}
```

## تعليمات البناء والنشر

### متطلبات البناء
- Android Studio Arctic Fox (2020.3.1) أو أحدث
- JDK 11 أو أحدث
- Gradle 7.0.2 أو أحدث

### خطوات البناء
1. استنساخ المستودع: `git clone https://github.com/username/accounting-app.git`
2. فتح المشروع في Android Studio
3. انتظار اكتمال مزامنة Gradle
4. بناء المشروع: `./gradlew build`

### إنشاء نسخة للإنتاج
1. تكوين ملف `keystore.properties` بمعلومات مفتاح التوقيع
2. تنفيذ الأمر: `./gradlew assembleRelease`
3. توقيع التطبيق: `./gradlew signReleaseBundle`

### النشر على Google Play
1. الدخول إلى وحدة تحكم Google Play
2. إنشاء تطبيق جديد
3. رفع حزمة التطبيق الموقعة (AAB)
4. إكمال معلومات القائمة (الوصف، لقطات الشاشة، الرمز)
5. تكوين التسعير والتوزيع
6. نشر التطبيق

## الصيانة والتحديثات

### إضافة ميزات جديدة
1. إنشاء فرع جديد: `git checkout -b feature/new-feature`
2. تنفيذ الميزة الجديدة
3. كتابة اختبارات للميزة الجديدة
4. دمج الفرع مع الفرع الرئيسي: `git merge feature/new-feature`

### تحديث متطلبات هيئة الزكاة والضريبة والجمارك
1. تحديث الأدوات المساعدة والخدمات المتعلقة بالضرائب والزكاة
2. تحديث واجهات برمجة التطبيقات للتوافق مع التغييرات في واجهة برمجة تطبيقات هيئة الزكاة والضريبة والجمارك
3. تحديث اختبارات التوافق
4. إصدار تحديث للتطبيق

## الخاتمة

هذه الوثائق توفر نظرة عامة على بنية التطبيق والمكونات الرئيسية وتعليمات البناء والنشر. للحصول على معلومات أكثر تفصيلاً، يرجى الرجوع إلى التعليقات في الكود المصدري.
